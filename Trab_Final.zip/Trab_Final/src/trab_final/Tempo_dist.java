/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trab_final;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import static javafx.css.StyleOrigin.USER_AGENT;
import org.json.JSONArray;

import org.json.*;
import org.json.JSONObject;



/**
 *
 * @author Fellipe Eduardo
 */
public class Tempo_dist {
    
    protected int value;
    private long[] times = null;
    
    private static String readAll(Reader rd) throws IOException {
        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1) {
            sb.append((char) cp);
        }
        return sb.toString();
    }

    private static JSONObject readJsonFromUrl(String url) throws IOException, JSONException {
        InputStream is = new URL(url).openStream();
        try {
            BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String jsonText = readAll(rd);
            JSONObject json = new JSONObject(jsonText);
            return json;
            }
        finally {
        is.close();
        }
  }
   
    public float getDuration(String origem, String destino, String mode) throws IOException{
        float value=0;
        String duration = null;
        try {
            JSONObject jo = readJsonFromUrl("https://maps.googleapis.com/maps/api/directions/json?origin="+origem+"&destination="+destino+"&mode="+mode+"&key=AIzaSyBZDFOdLsshBWihncwDHKnuV4x7KSaYKVM");
            List<List<HashMap<String,Integer>>> pact = parse(jo);           
                for(int i=0;i<pact.size();i++){
                    // Fetching i-th route
                    List<HashMap<String, Integer>> path = pact.get(i);
                 // Fetching all the points in i-th route
                    for(int j=0;j<path.size();j++){
                        HashMap<String,Integer> point = path.get(j);
                        if(j==0){ // Get duration from the list
                            value = point.get("duration")/60;
                        continue;
                        }
                    }
                }
            

        return value;
        } 
        catch (JSONException e) {
            e.printStackTrace();
        }
        return 0;
        }
        
        public List<List<HashMap<String,Integer>>> parse(JSONObject jObject){
 
        List<List<HashMap<String, Integer>>> routes = new ArrayList<List<HashMap<String,Integer>>>() ;
        JSONArray jRoutes = null;
        JSONArray jLegs = null;
        JSONObject jDistance = null;
        JSONObject jDuration = null;
 
        try {
 
            jRoutes = jObject.getJSONArray("routes");
 
            /** Traversing all routes */
            for(int i=0;i<jRoutes.length();i++){
                jLegs = ( (JSONObject)jRoutes.get(i)).getJSONArray("legs");
 
                List<HashMap<String, Integer>> path = new ArrayList<HashMap<String, Integer>>();
 
                /** Traversing all legs */
                for(int j=0;j<jLegs.length();j++){
 
                    /** Getting distance from the json data *//*
                    jDistance = ((JSONObject) jLegs.get(j)).getJSONObject("distance");
                    HashMap<String, String> hmDistance = new HashMap<String, String>();
                    hmDistance.put("distance", jDistance.getString("text"));*/
 
                    /** Getting duration from the json data */
                    jDuration = ((JSONObject) jLegs.get(j)).getJSONObject("duration");
                    HashMap<String, Integer> hmDuration = new HashMap<String, Integer>();
                    hmDuration.put("duration", jDuration.getInt("value"));
 
                    /** Adding distance object to the path */
                    //path.add(hmDistance);
 
                    /** Adding duration object to the path */
                    path.add(hmDuration);
 
                    }
                routes.add(path);
            }
        } catch (JSONException e) {
           e.printStackTrace();
        }catch (Exception e){
        }
        return routes;
    }
        public void sendGET(String path, float value) throws IOException {
		URL obj = new URL("http://192.168.56.101:8080/ScadaBR/httpds?"+path+"="+value);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("GET");
		//con.setRequestProperty("User-Agent", USER_AGENT);
		int responseCode = con.getResponseCode();
		System.out.println("GET Response Code :: " + responseCode);
		if (responseCode == HttpURLConnection.HTTP_OK) { // success
			BufferedReader in = new BufferedReader(new InputStreamReader(
					con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			// print result
			System.out.println(response.toString());
		} else {
			System.out.println("GET request not worked");
		}

	}
 }
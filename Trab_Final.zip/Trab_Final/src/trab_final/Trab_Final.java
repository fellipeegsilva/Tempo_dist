/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trab_final;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author Fellipe Eduardo
 */
public class Trab_Final {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     * @throws java.lang.InterruptedException
     */
    public static void main(String[] args) throws IOException, InterruptedException {
        // TODO code application logic here
        Tempo_dist dur = new Tempo_dist();
        int countdown = 0;
        int min = 60;
        int pause = 3;
        
        while(countdown < 5*min){
        dur.sendGET("vgc",dur.getDuration("-26.9211709,-49.0981554","-26.9152648,-49.0842865","driving"));
        dur.sendGET("pbc",dur.getDuration("-26.9211709,-49.0981554","-26.916379,-49.071185","driving"));
        dur.sendGET("cic",dur.getDuration("-26.9211709,-49.0981554","-26.894313,-49.232925","driving"));
        dur.sendGET("cgc",dur.getDuration("-26.9211709,-49.0981554","-26.932149,-48.954884","driving"));
        dur.sendGET("cpc",dur.getDuration("-26.9211709,-49.0981554","-26.751159,-49.173394","driving"));
        dur.sendGET("vgb",dur.getDuration("-26.9211709,-49.0981554","-26.9152648,-49.0842865","transit"));
        dur.sendGET("pbb",dur.getDuration("-26.9211709,-49.0981554","-26.916379,-49.071185","transit"));
        dur.sendGET("cib",dur.getDuration("-26.9211709,-49.0981554","-26.894313,-49.232925","transit"));
        dur.sendGET("cgb",dur.getDuration("-26.9211709,-49.0981554","-26.932149,-48.954884","transit"));
        dur.sendGET("cpb",dur.getDuration("-26.9211709,-49.0981554","-26.751159,-49.173394","transit"));
        
        TimeUnit.SECONDS.sleep(pause);
        countdown = countdown+pause;
                
        }
    
}
}

    
